"""
 Compreensão de Lista (List Comprehension) em Python
---------------------------------------------------------

O que é:
    Uma forma curta e prática de criar listas a partir de outras listas,
    ranges ou strings, sem precisar usar vários "for" e "append".

Sintaxe:
    [expressão for item in iterável if condição]

- expressão → o que você quer guardar na lista.
- for item in iterável → percorre os elementos.
- if condição → (opcional) serve para filtrar.

Para que serve:
    - Deixar o código menor e mais fácil de ler.
    - Criar listas transformando dados ou filtrando informações.
"""

# ---------------------------
# Exemplo 1: Criando uma lista de números dobrados
dobrados = [x * 2 for x in range(5)]
print("Números dobrados:", dobrados)
# Saída: [0, 2, 4, 6, 8]


# ---------------------------
# Exemplo 2: Trabalhando com strings
# Transformar cada letra em maiúscula
letras = [letra.upper() for letra in "python"]
print("Letras em maiúsculas:", letras)
# Saída: ['P', 'Y', 'T', 'H', 'O', 'N']


# ---------------------------
# Exemplo 3: Usando filtro (if)
# Guardar apenas os números pares de 0 a 10
pares = [n for n in range(11) if n % 2 == 0]
print("Números pares de 0 a 10:", pares)
# Saída: [0, 2, 4, 6, 8, 10]
